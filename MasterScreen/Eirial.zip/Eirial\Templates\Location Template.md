## Type: template

## Quick Glance
- text
	- size: 1rem
- type: list
- of
	- type: text
- default: Population, Test

## Social
- type: text
- default: Social
- text
	- align: center
	- size: 2rem

## Political
- type: text
- default: Political
- text
	- size: 2rem
	- align: center

## Economic
- type: text
- default: Economic
- text
	- size: 2rem
	- align: center

## Religious
- type: text
- default: Religious
- text
	- size: 2rem
	- align: center

## Military
- type: text
- default: Military
- text
	- size: 2rem
	- align: center

## View on Magic
- type: text
- default: Views of Magic
- text
	- size: 2rem
	- align: center