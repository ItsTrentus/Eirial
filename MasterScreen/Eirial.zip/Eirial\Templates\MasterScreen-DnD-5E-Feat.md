## Type: template

## Icon: eagle-emblem

## Creates: dnd 5e feat

## Layout

|          |
| -------- |
| Details  |
| Benefits |
| Effects  |


## Details
- type: text
- border
	- style: none

## Benefits
- type: list
- of
	- type: text

## Effects
- type: effects